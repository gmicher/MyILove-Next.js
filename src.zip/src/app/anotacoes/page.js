'use client';

import { useEffect } from 'react';
import Script from 'next/script';

export default function Page() {
  useEffect(() => {
    // Lucide stub (evita erro se script ainda não carregou)
    if (typeof window !== 'undefined' && !window.lucide) { window.lucide = { createIcons: () => {} }; }

    // Aguardar DOM montado para ligar eventos com segurança
    requestAnimationFrame(() => {
      429: Too Many Requests
      For more on scraping GitHub and how it may affect your rights, please review our Terms of Service (https://docs.github.com/en/site-policy/github-terms/github-terms-of-service).

      // Recriar ícones após quaisquer mutações
      try { window.lucide?.createIcons?.(); } catch {} 
    });
  }, []);

  return (
    <>
      <link rel="stylesheet" href="/style.css" />
      <Script
        src="https://unpkg.com/lucide@latest"
        strategy="afterInteractive"
        onLoad={() => { try { window.lucide?.createIcons?.(); } catch {} }}
      />
      <div dangerouslySetInnerHTML={{ __html: `
  <!-- Estrutura principal da página -->
  <div class="container">

    <!-- Sidebar (menu de navegação lateral) -->
    <nav class="sidebar">
      <!-- Logotipo ou título da aplicação -->
      <h2>MyILove 💕</h2>
      
      <!-- Lista de navegação, permitindo acesso rápido às páginas do sistema -->
      <ul>
        <li><a href="/"><i data-lucide="home"></i> Início</a></li>
        <li><a href="/eventos"><i data-lucide="calendar"></i> Eventos</a></li>
        <li><a href="/desejos"><i data-lucide="heart"></i> Desejos</a></li>
        <li><a href="/anotacoes"><i data-lucide="file-text"></i> Anotações</a></li>
        <li><a href="/fotos"><i data-lucide="camera"></i> Fotos</a></li>
        <li><a href="/viagens"><i data-lucide="map"></i> Viagens</a></li>
        <li><a href="/realizadas"><i data-lucide="check-circle"></i> Realizadas</a></li>
        <li><a href="/config"><i data-lucide="settings"></i> Configurações</a></li>
      </ul>
    </nav>

    <!-- Conteúdo principal -->
    <main class="content">
      
      <!-- Cabeçalho da seção de anotações -->
      <div class="page-header">
        <h2>Anotações 📝</h2>
        
        <!-- Botão que abre o modal de nova anotação, permitindo inclusão de conteúdo -->
        <button class="add-btn" onclick="openNoteModal()">
          <i data-lucide="plus"></i> Nova Anotação
        </button>
      </div>

      <!-- Barra de busca: filtra as anotações conforme o usuário digita -->
      <div class="search-bar">
        <input type="text" id="searchInput" placeholder="Buscar anotações..." onkeyup="searchNotes()">
        <i data-lucide="search"></i>
      </div>

      <!-- Filtros: permitem segmentar anotações por categoria -->
      <div class="notes-filter">
        <button class="filter-btn active" onclick="filterNotes('all')">Todas</button>
        <button class="filter-btn" onclick="filterNotes('memories')">Memórias</button>
        <button class="filter-btn" onclick="filterNotes('ideas')">Ideias</button>
        <button class="filter-btn" onclick="filterNotes('important')">Importante</button>
      </div>

      <!-- Área dinâmica onde as anotações cadastradas serão exibidas -->
      <div class="notes-grid" id="notesGrid">
        <!-- Estado inicial: mensagem exibida quando não há anotações cadastradas -->
        <p class="empty-state">Nenhuma anotação ainda. Que tal registrar uma memória especial? 💭</p>
      </div>
    </main>
  </div>

  <!-- Modal: componente flutuante para adicionar ou editar anotações -->
  <div id="noteModal" class="modal">
    <div class="modal-content large">
      
      <!-- Cabeçalho do modal -->
      <div class="modal-header">
        <h3 id="modalTitle">Nova Anotação</h3>
        <!-- Botão de fechar o modal -->
        <span class="close" onclick="closeNoteModal()">&times;</span>
      </div>

      <!-- Formulário para cadastro ou edição de anotações -->
      <form id="noteForm">
        
        <!-- Campo para o título da anotação -->
        <input type="text" id="noteTitle" placeholder="Título da anotação" required>
        
        <!-- Campo de texto maior para o conteúdo da anotação -->
        <textarea id="noteContent" placeholder="Escreva aqui..." required></textarea>

        <!-- Linha do formulário com categoria e humor -->
        <div class="form-row">
          
          <!-- Seletor de categoria: define a classificação da anotação -->
          <select id="noteCategory" required>
            <option value="">Categoria</option>
            <option value="memories">Memórias</option>
            <option value="ideas">Ideias</option>
            <option value="important">Importante</option>
          </select>

          <!-- Seletor de humor: adiciona um contexto emocional à anotação -->
          <div class="mood-selector">
            <label>Humor:</label>
            <div class="mood-options">
              <span class="mood" data-mood="happy" onclick="selectMood('happy')">😊</span>
              <span class="mood" data-mood="love" onclick="selectMood('love')">😍</span>
              <span class="mood" data-mood="excited" onclick="selectMood('excited')">🤩</span>
              <span class="mood" data-mood="peaceful" onclick="selectMood('peaceful')">😌</span>
              <span class="mood" data-mood="thoughtful" onclick="selectMood('thoughtful')">🤔</span>
            </div>
          </div>
        </div>

        <!-- Campos ocultos de apoio para lógica de edição e humor -->
        <input type="hidden" id="noteMood" value="happy"> <!-- Valor inicial do humor -->
        <input type="hidden" id="editingId" value=""> <!-- Usado para identificar se a anotação é nova ou uma edição -->

        <!-- Botão de envio do formulário -->
        <button type="submit" class="submit-btn">Salvar Anotação</button>
      </form>
    </div>
  </div>

  <!-- Importação dos scripts JavaScript responsáveis pela lógica -->
   <!-- Script geral (menu, comportamentos globais) -->
   <!-- Script específico para manipulação das anotações -->
` }} />
    </>
  );
}
