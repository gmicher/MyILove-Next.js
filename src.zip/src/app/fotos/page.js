'use client';

import { useEffect } from 'react';
import Script from 'next/script';

export default function Page() {
  useEffect(() => {
    // Lucide stub (evita erro se script ainda não carregou)
    if (typeof window !== 'undefined' && !window.lucide) { window.lucide = { createIcons: () => {} }; }

    // Aguardar DOM montado para ligar eventos com segurança
    requestAnimationFrame(() => {
      // Recupera fotos do localStorage ou cria array vazio se não houver
      let photos = JSON.parse(localStorage.getItem('photos')) || [];
      // Filtro atual da galeria (all, selfie, date, travel, special, favorites)
      let currentFilter = 'all';
      
      // Executa funções quando a página carrega
      
        displayPhotos(); // Exibe as fotos na grid
        updateStats();   // Atualiza as estatísticas da galeria
      });
      
      // Abre o modal de adicionar foto
      function openPhotoModal() {
        document.getElementById('photoModal').style.display = 'flex';
        // Define a data atual no campo de data
        document.getElementById('photoDate').value = new Date().toISOString().split('T')[0];
      }
      
      // Fecha o modal de adicionar foto e reseta o formulário
      function closePhotoModal() {
        document.getElementById('photoModal').style.display = 'none';
        document.getElementById('photoForm').reset();
        document.getElementById('photoPreview').innerHTML = ''; // Limpa preview
      }
      
      // Fecha o modal de visualização de foto
      function closeViewModal() {
        document.getElementById('viewModal').style.display = 'none';
      }
      
      // Preview da foto selecionada no input
      document.getElementById('photoFile')?.addEventListener('change', function(e) {
        const file = e.target.files[0]; // Pega arquivo selecionado
        const preview = document.getElementById('photoPreview');
      
        if (file) {
          const reader = new FileReader();
          // Quando a leitura do arquivo termina, cria uma imagem no preview
          reader.onload = function(e) {
            preview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
          };
          reader.readAsDataURL(file); // Lê arquivo como URL de dados
        }
      });
      
      // Evento de submissão do formulário de nova foto
      document.getElementById('photoForm')?.addEventListener('submit', (e) => {
        e.preventDefault(); // Evita reload da página
      
        const fileInput = document.getElementById('photoFile');
        const file = fileInput.files[0];
      
        if (file) {
          const reader = new FileReader();
          reader.onload = function(e) {
            // Cria objeto photo com todos os dados
            const photo = {
              id: Date.now(), // ID único
              title: document.getElementById('photoTitle').value,
              description: document.getElementById('photoDescription').value,
              date: document.getElementById('photoDate').value,
              category: document.getElementById('photoCategory').value,
              location: document.getElementById('photoLocation').value,
              image: e.target.result, // Conteúdo da imagem
              isFavorite: false,      // Se é favorita
              createdAt: new Date().toISOString()
            };
      
            photos.unshift(photo); // Adiciona no início do array
            localStorage.setItem('photos', JSON.stringify(photos)); // Salva no localStorage
      
            displayPhotos(); // Atualiza grid
            updateStats();   // Atualiza estatísticas
            closePhotoModal(); // Fecha modal
          };
          reader.readAsDataURL(file);
        }
      });
      
      // Função para alterar filtro da galeria
      function filterPhotos(category) {
        currentFilter = category;
      
        // Remove classe active de todos os botões
        (document.querySelectorAll('.filter-btn') || []).forEach(btn => {
          btn.classList.remove('active');
        });
        event.target.classList.add('active'); // Adiciona active no botão clicado
      
        displayPhotos(); // Atualiza grid com o filtro
      }
      
      // Função que exibe as fotos na grid
      function displayPhotos() {
        const grid = document.getElementById('photosGrid');
      
        let filteredPhotos = photos;
      
        // Filtra por favoritas ou categoria específica
        if (currentFilter === 'favorites') {
          filteredPhotos = photos.filter(photo => photo.isFavorite);
        } else if (currentFilter !== 'all') {
          filteredPhotos = photos.filter(photo => photo.category === currentFilter);
        }
      
        // Se não houver fotos, exibe placeholder
        if (filteredPhotos.length === 0) {
          grid.innerHTML = `
            <div class="photo-placeholder">
              <i data-lucide="camera"></i>
              <p>Nenhuma foto encontrada</p>
              <span>Comece a criar memórias visuais do seu amor! 💕</span>
            </div>
          `;
          lucide.createIcons(); // Atualiza ícones Lucide
          return;
        }
      
        // Mapeia as fotos filtradas para o HTML
        grid.innerHTML = filteredPhotos.map(photo => `
          <div class="photo-item" onclick="viewPhoto(${photo.id})">
            <div class="photo-image">
              <img src="${photo.image}" alt="${photo.title}">
              <div class="photo-overlay">
                <div class="photo-actions">
                  <!-- Botão de favorita -->
                  <button onclick="event.stopPropagation(); toggleFavorite(${photo.id})" class="favorite-btn ${photo.isFavorite ? 'active' : ''}">
                    <i data-lucide="heart"></i>
                  </button>
                  <!-- Botão de excluir -->
                  <button onclick="event.stopPropagation(); deletePhoto(${photo.id})" class="delete-btn">
                    <i data-lucide="trash-2"></i>
                  </button>
                </div>
              </div>
            </div>
            <div class="photo-info">
              <h4>${photo.title}</h4>
              <p class="photo-date">${formatDate(photo.date)}</p>
              ${photo.location ? `<p class="photo-location">📍 ${photo.location}</p>` : ''}
            </div>
          </div>
        `).join('');
      
        lucide.createIcons(); // Atualiza ícones Lucide
      }
      
      // Abre modal de visualização da foto
      function viewPhoto(id) {
        const photo = photos.find(p => p.id === id);
        if (photo) {
          const content = document.getElementById('photoViewContent');
          content.innerHTML = `
            <div class="photo-view">
              <img src="${photo.image}" alt="${photo.title}">
              <div class="photo-details">
                <h3>${photo.title}</h3>
                <p class="photo-date">${formatDate(photo.date)}</p>
                ${photo.location ? `<p class="photo-location">📍 ${photo.location}</p>` : ''}
                ${photo.description ? `<p class="photo-description">${photo.description}</p>` : ''}
                <div class="photo-category">${getCategoryIcon(photo.category)} ${getCategoryName(photo.category)}</div>
              </div>
            </div>
          `;
          document.getElementById('viewModal').style.display = 'flex';
        }
      }
      
      // Alterna favorita / desfavorita
      function toggleFavorite(id) {
        const photo = photos.find(p => p.id === id);
        if (photo) {
          photo.isFavorite = !photo.isFavorite;
          localStorage.setItem('photos', JSON.stringify(photos));
          displayPhotos();
          updateStats();
        }
      }
      
      // Exclui uma foto
      function deletePhoto(id) {
        if (confirm('Tem certeza que deseja excluir esta foto?')) {
          photos = photos.filter(photo => photo.id !== id);
          localStorage.setItem('photos', JSON.stringify(photos));
          displayPhotos();
          updateStats();
        }
      }
      
      // Atualiza estatísticas da galeria
      function updateStats() {
        document.getElementById('totalPhotos').textContent = photos.length;
        document.getElementById('totalAlbums').textContent = new Set(photos.map(p => p.category)).size;
        document.getElementById('favoritesCount').textContent = photos.filter(p => p.isFavorite).length;
      }
      
      // Retorna ícone baseado na categoria
      function getCategoryIcon(category) {
        const icons = {
          selfie: '🤳',
          date: '💕',
          travel: '✈️',
          special: '⭐'
        };
        return icons[category] || '📸';
      }
      
      // Retorna nome legível da categoria
      function getCategoryName(category) {
        const names = {
          selfie: 'Selfie',
          date: 'Encontro',
          travel: 'Viagem',
          special: 'Momento especial'
        };
        return names[category] || 'Foto';
      }
      
      // Formata datas para pt-BR
      function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('pt-BR');
      }
      if (typeof closePhotoModal === 'function') window.closePhotoModal = closePhotoModal;
      if (typeof closeViewModal === 'function') window.closeViewModal = closeViewModal;
      if (typeof filterPhotos === 'function') window.filterPhotos = filterPhotos;
      if (typeof openPhotoModal === 'function') window.openPhotoModal = openPhotoModal;

      // Recriar ícones após quaisquer mutações
      try { window.lucide?.createIcons?.(); } catch {} 
    });
  }, []);

  return (
    <>
      <link rel="stylesheet" href="/style.css" />
      <Script
        src="https://unpkg.com/lucide@latest"
        strategy="afterInteractive"
        onLoad={() => { try { window.lucide?.createIcons?.(); } catch {} }}
      />
      <div dangerouslySetInnerHTML={{ __html: `
  <!-- Container principal da aplicação -->
  <div class="container">

    <!-- Sidebar de navegação lateral -->
    <nav class="sidebar">
      <h2>MyILove 💕</h2>
      <ul>
        <!-- Cada item de menu possui um ícone e um link -->
        <li><a href="/"><i data-lucide="home"></i> Início</a></li>
        <li><a href="/eventos"><i data-lucide="calendar"></i> Eventos</a></li>
        <li><a href="/desejos"><i data-lucide="heart"></i> Desejos</a></li>
        <li><a href="/anotacoes"><i data-lucide="file-text"></i> Anotações</a></li>
        <li><a href="/fotos"><i data-lucide="camera"></i> Fotos</a></li>
        <li><a href="/viagens"><i data-lucide="map"></i> Viagens</a></li>
        <li><a href="/realizadas"><i data-lucide="check-circle"></i> Realizadas</a></li>
        <li><a href="/config"><i data-lucide="settings"></i> Configurações</a></li>
      </ul>
    </nav>

    <!-- Conteúdo principal da página -->
    <main class="content">

      <!-- Cabeçalho da página com título e botão de adicionar foto -->
      <div class="page-header">
        <h2>Galeria de Fotos 📸</h2>
        <!-- Botão abre modal para adicionar nova foto -->
        <button class="add-btn" onclick="openPhotoModal()">
          <i data-lucide="plus"></i> Adicionar Foto
        </button>
      </div>

      <!-- Estatísticas da galeria de fotos -->
      <div class="gallery-stats">
        <div class="stat-item">
          <!-- Total de fotos, atualizado dinamicamente via JS -->
          <span id="totalPhotos">0</span>
          <p>Total de fotos</p>
        </div>
        <div class="stat-item">
          <!-- Total de álbuns, se houver organização por álbuns -->
          <span id="totalAlbums">0</span>
          <p>Álbuns</p>
        </div>
        <div class="stat-item">
          <!-- Total de fotos marcadas como favoritas -->
          <span id="favoritesCount">0</span>
          <p>Favoritas</p>
        </div>
      </div>

      <!-- Filtros da galeria para exibir fotos por categoria -->
      <div class="gallery-filter">
        <button class="filter-btn active" onclick="filterPhotos('all')">Todas</button>
        <button class="filter-btn" onclick="filterPhotos('selfie')">Selfies</button>
        <button class="filter-btn" onclick="filterPhotos('date')">Encontros</button>
        <button class="filter-btn" onclick="filterPhotos('travel')">Viagens</button>
        <button class="filter-btn" onclick="filterPhotos('special')">Especiais</button>
        <button class="filter-btn" onclick="filterPhotos('favorites')">Favoritas</button>
      </div>

      <!-- Grid da galeria de fotos -->
      <div class="photos-grid" id="photosGrid">
        <!-- Placeholder exibido quando não há fotos cadastradas -->
        <div class="photo-placeholder">
          <i data-lucide="camera"></i>
          <p>Nenhuma foto ainda</p>
          <span>Comece a criar memórias visuais do seu amor! 💕</span>
        </div>
      </div>
    </main>
  </div>

  <!-- Modal para adicionar uma nova foto -->
  <div id="photoModal" class="modal">
    <div class="modal-content">
      <div class="modal-header">
        <h3>Adicionar Foto</h3>
        <!-- Botão para fechar o modal -->
        <span class="close" onclick="closePhotoModal()">&times;</span>
      </div>
      <!-- Formulário de upload de foto -->
      <form id="photoForm">
        <div class="photo-upload">
          <!-- Input de arquivo obrigatório -->
          <input type="file" id="photoFile" accept="image/*" required>
          <!-- Label estilizado para o input de arquivo -->
          <label for="photoFile" class="upload-label">
            <i data-lucide="upload"></i>
            Escolher foto
          </label>
          <!-- Preview da imagem selecionada antes do envio -->
          <div id="photoPreview" class="photo-preview"></div>
        </div>
        <!-- Campos de informações da foto -->
        <input type="text" id="photoTitle" placeholder="Título da foto" required>
        <textarea id="photoDescription" placeholder="Descrição ou história desta foto..."></textarea>
        <input type="date" id="photoDate" required>
        <select id="photoCategory" required>
          <option value="">Categoria</option>
          <option value="selfie">Selfie</option>
          <option value="date">Encontro</option>
          <option value="travel">Viagem</option>
          <option value="special">Momento especial</option>
        </select>
        <input type="text" id="photoLocation" placeholder="Local (opcional)">
        <button type="submit" class="submit-btn">Adicionar Foto</button>
      </form>
    </div>
  </div>

  <!-- Modal para visualizar foto em tamanho maior -->
  <div id="viewModal" class="modal photo-viewer">
    <div class="modal-content large">
      <!-- Botão para fechar a visualização -->
      <span class="close" onclick="closeViewModal()">&times;</span>
      <!-- Conteúdo da foto exibida -->
      <div id="photoViewContent"></div>
    </div>
  </div>

  <!-- Scripts gerais e específicos -->
  
  
` }} />
    </>
  );
}
