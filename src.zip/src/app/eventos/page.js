'use client';

import { useEffect } from 'react';
import Script from 'next/script';

export default function Page() {
  useEffect(() => {
    // Lucide stub (evita erro se script ainda não carregou)
    if (typeof window !== 'undefined' && !window.lucide) { window.lucide = { createIcons: () => {} }; }

    // Aguardar DOM montado para ligar eventos com segurança
    requestAnimationFrame(() => {
      // Configuração inicial
      
      // Data atual do calendário
      let currentDate = new Date();
      
      // Array de eventos, carregando do localStorage ou vazio caso não exista
      let events = JSON.parse(localStorage.getItem('events')) || [];
      
      // Parse local de 'YYYY-MM-DD' para Date em horário local (00:00)
      function parseLocalDate(isoDate) {
        const [y, m, d] = (isoDate || '').split('-').map(Number);
        return new Date(y, (m || 1) - 1, d || 1);
      }
      
      // Executa funções quando a página termina de carregar
      
        updateCalendar();    // Atualiza a visualização do calendário
        displayEvents();     // Mostra os eventos cadastrados
        updateMonthDisplay();// Atualiza o nome do mês na tela
      });
      
      // Funções de controle do mês
      
      // Atualiza o título do mês atual no calendário
      function updateMonthDisplay() {
        const months = [
          'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
          'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
        ];
        document.getElementById('currentMonth').textContent = 
          `${months[currentDate.getMonth()]} ${currentDate.getFullYear()}`;
      }
      
      // Avança ou retrocede meses
      function changeMonth(direction) {
        currentDate.setMonth(currentDate.getMonth() + direction);
        updateCalendar();
        updateMonthDisplay();
      }
      
      // Funções do calendário
      
      // Atualiza o calendário com os dias do mês
      function updateCalendar() {
        const grid = document.getElementById('calendarGrid');
        grid.innerHTML = ''; // Limpa a grid antes de renderizar
      
        // Cabeçalho com os dias da semana
        const daysOfWeek = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
        daysOfWeek.forEach(day => {
          const dayElement = document.createElement('div');
          dayElement.className = 'calendar-day-header';
          dayElement.textContent = day;
          grid.appendChild(dayElement);
        });
      
        // Calcula o primeiro e último dia do mês
        const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
        const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
      
        // Define a data inicial exibida no calendário (início da semana do primeiro dia)
        const startDate = new Date(firstDay);
        startDate.setDate(startDate.getDate() - firstDay.getDay());
      
        // Cria 42 células (6 semanas) para exibir os dias
        for (let i = 0; i < 42; i++) {
          const date = new Date(startDate);
          date.setDate(startDate.getDate() + i);
          
          const dayElement = document.createElement('div');
          dayElement.className = 'calendar-day';
          dayElement.textContent = date.getDate();
      
          // Diferencia dias de outros meses
          if (date.getMonth() !== currentDate.getMonth()) {
            dayElement.classList.add('other-month');
          }
      
          // Destaca o dia atual
          if (date.toDateString() === new Date().toDateString()) {
            dayElement.classList.add('today');
          }
      
          // Verifica se há algum evento nesta data
          const hasEvent = events.some(ev =>
        parseLocalDate(ev.date).toDateString() === date.toDateString()
      );
      
          if (hasEvent) {
            dayElement.classList.add('has-event');
          }
      
          grid.appendChild(dayElement);
        }
      }
      
      // Modal de criação de evento
      
      function openEventModal() {
        document.getElementById('eventModal').style.display = 'flex';
      }
      
      function closeEventModal() {
        document.getElementById('eventModal').style.display = 'none';
        document.getElementById('eventForm').reset();
      }
      
      // Cadastro de novos eventos
      
      document.getElementById('eventForm')?.addEventListener('submit', (e) => {
        e.preventDefault(); // Impede o envio padrão do formulário
      
        // Cria objeto do evento com dados do formulário
        const event = {
          id: Date.now(), // ID único baseado no timestamp
          title: document.getElementById('eventTitle').value,
          date: document.getElementById('eventDate').value,
          time: document.getElementById('eventTime').value,
          description: document.getElementById('eventDescription').value,
          category: document.getElementById('eventCategory').value
        };
      
        events.push(event); // Adiciona ao array
        localStorage.setItem('events', JSON.stringify(events)); // Salva no localStorage
      
        displayEvents();    // Atualiza a lista de eventos
        updateCalendar();   // Atualiza o calendário para mostrar marcação
        closeEventModal();  // Fecha o modal
      });
      
      // Exibição dos eventos
      
      function displayEvents() {
        const list = document.getElementById('eventsList');
      
        if (!events || events.length === 0) {
          list.innerHTML = '<p class="empty-state">Nenhum evento cadastrado. Que tal planejar algo especial? 💖</p>';
          return;
        }
      
        // Normaliza "hoje" para 00:00 local
        const today = new Date();
        today.setHours(0, 0, 0, 0);
      
        // Converte todas as datas para local (00:00) antes de operar
        const withLocal = events.map(ev => ({ ...ev, _d: parseLocalDate(ev.date) }));
      
        const upcoming = withLocal
          .filter(ev => ev._d >= today)
          .sort((a, b) => a._d - b._d);
      
        // Se quiser, mostre um fallback dos 5 mais recentes do passado caso não haja próximos
        // (descomente se fizer sentido pra você)
        // const past = withLocal.filter(ev => ev._d < today).sort((a,b) => b._d - a._d).slice(0,5);
      
        list.innerHTML = upcoming.length
          ? upcoming.map(event => `
              <div class="event-item">
                <div class="event-icon">${getCategoryIcon(event.category)}</div>
                <div class="event-details">
                  <h4>${event.title}</h4>
                  <p class="event-date">${formatDate(event.date)} ${event.time ? `às ${event.time}` : ''}</p>
                  ${event.description ? `<p class="event-description">${event.description}</p>` : ''}
                </div>
                <button class="delete-btn" onclick="deleteEvent(${event.id})">
                  <i data-lucide="trash-2"></i>
                </button>
              </div>
            `).join('')
          : '<p class="empty-state">Nenhum evento futuro. Que tal planejar algo especial? 💖</p>';
      
        lucide.createIcons();
      }
      
      
      // Funções auxiliares
      
      function getCategoryIcon(category) {
        const icons = {
          date: '💕',        // Encontro
          anniversary: '🎉', // Aniversário
          travel: '✈️',      // Viagem
          special: '⭐'       // Evento especial
        };
        return icons[category] || '📅';
      }
      
      // Formata a data no padrão brasileiro
      function formatDate(dateString) {
        const date = parseLocalDate(dateString);
        return date.toLocaleDateString('pt-BR');
      }
      
      
      // Excluir evento
      function deleteEvent(id) {
        if (confirm('Tem certeza que deseja excluir este evento?')) {
          events = events.filter(event => event.id !== id); // Remove do array
          localStorage.setItem('events', JSON.stringify(events)); // Atualiza localStorage
          displayEvents();  // Atualiza lista
          updateCalendar(); // Atualiza calendário
        }
      }
      // ---------- Helpers robustos ----------
      function parseLocalDate(isoDate) {
        // Aceita 'YYYY-MM-DD' e também 'YYYY-MM-DDTHH:mm' se vier
        if (!isoDate) return new Date(NaN);
        const onlyDate = String(isoDate).split('T')[0];
        const [y, m, d] = onlyDate.split('-').map(Number);
        return new Date(y, (m || 1) - 1, d || 1);
      }
      
      function todayLocal00() {
        const t = new Date();
        t.setHours(0,0,0,0);
        return t;
      }
      
      // ---------- Substitua displayEvents por esta ----------
      function displayEvents() {
        const list = document.getElementById('eventsList');
      
        if (!events || events.length === 0) {
          list.innerHTML = '<p class="empty-state">Nenhum evento cadastrado. Que tal planejar algo especial? 💖</p>';
          return;
        }
      
        const t0 = todayLocal00();
      
        // Normaliza datas em local 00:00, e guarda um campo calculado _d para ordenar/filtrar
        const normalized = events
          .map(ev => ({ ...ev, _d: parseLocalDate(ev.date) }))
          .filter(ev => !isNaN(ev._d)); // remove datas inválidas, se houver
      
        // Próximos (>= hoje)
        const upcoming = normalized
          .filter(ev => ev._d >= t0)
          .sort((a, b) => a._d - b._d);
      
        // Fallback: se não houver próximos, mostra os 5 mais recentes do passado
        const fallbackPast = normalized
          .filter(ev => ev._d < t0)
          .sort((a, b) => b._d - a._d)
          .slice(0, 5);
      
        const toShow = upcoming.length ? upcoming : fallbackPast;
      
        list.innerHTML = toShow.length
          ? toShow.map(event => `
              <div class="event-item">
                <div class="event-icon">${getCategoryIcon(event.category)}</div>
                <div class="event-details">
                  <h4>${event.title}</h4>
                  <p class="event-date">${formatDate(event.date)} ${event.time ? `às ${event.time}` : ''}</p>
                  ${event.description ? `<p class="event-description">${event.description}</p>` : ''}
                </div>
                <button class="delete-btn" onclick="deleteEvent(${event.id})">
                  <i data-lucide="trash-2"></i>
                </button>
              </div>
            `).join('')
          : '<p class="empty-state">Nenhum evento para exibir.</p>';
      
        if (window.lucide?.createIcons) lucide.createIcons();
      }
      
      // ---------- Ajuste no calendário dentro de updateCalendar ----------
      /* Dentro de updateCalendar(), troque a verificação hasEvent por: */
      /// const hasEvent = events.some(event =>
      ///   parseLocalDate(event.date).toDateString() === date.toDateString()
      /// );
      
      // ---------- Substitua formatDate por esta ----------
      function formatDate(dateString) {
        const d = parseLocalDate(dateString);
        return isNaN(d) ? dateString : d.toLocaleDateString('pt-BR');
      }
      if (typeof changeMonth === 'function') window.changeMonth = changeMonth;
      if (typeof closeEventModal === 'function') window.closeEventModal = closeEventModal;
      if (typeof openEventModal === 'function') window.openEventModal = openEventModal;

      // Recriar ícones após quaisquer mutações
      try { window.lucide?.createIcons?.(); } catch {} 
    });
  }, []);

  return (
    <>
      <link rel="stylesheet" href="/style.css" />
      <Script
        src="https://unpkg.com/lucide@latest"
        strategy="afterInteractive"
        onLoad={() => { try { window.lucide?.createIcons?.(); } catch {} }}
      />
      <div dangerouslySetInnerHTML={{ __html: `
  <!-- Container principal da aplicação, organiza sidebar + conteúdo -->
  <div class="container">

    <!-- Sidebar lateral com navegação do aplicativo -->
    <nav class="sidebar">
      <h2>MyILove 💕</h2>
      <ul>
        <!-- Cada item de menu leva a uma página diferente -->
        <li><a href="/"><i data-lucide="home"></i> Início</a></li>
        <li><a href="/eventos"><i data-lucide="calendar"></i> Eventos</a></li>
        <li><a href="/desejos"><i data-lucide="heart"></i> Desejos</a></li>
        <li><a href="/anotacoes"><i data-lucide="file-text"></i> Anotações</a></li>
        <li><a href="/fotos"><i data-lucide="camera"></i> Fotos</a></li>
        <li><a href="/viagens"><i data-lucide="map"></i> Viagens</a></li>
        <li><a href="/realizadas"><i data-lucide="check-circle"></i> Realizadas</a></li>
        <li><a href="/config"><i data-lucide="settings"></i> Configurações</a></li>
      </ul>
    </nav>

    <!-- Área principal de conteúdo -->
    <main class="content">
      <!-- Cabeçalho da página com título e botão de adicionar evento -->
      <div class="page-header">
        <h2>Eventos 📅</h2>
        <button class="add-btn" onclick="openEventModal()">
          <i data-lucide="plus"></i> Adicionar Evento
        </button>
      </div>

      <!-- Seção do calendário -->
      <div class="calendar-view">
        <div class="calendar-header">
          <!-- Botões para navegar entre meses -->
          <button onclick="changeMonth(-1)"><i data-lucide="chevron-left"></i></button>
          <h3 id="currentMonth"></h3> <!-- Nome do mês atual -->
          <button onclick="changeMonth(1)"><i data-lucide="chevron-right"></i></button>
        </div>
        <!-- Grid onde os dias do mês serão exibidos -->
        <div class="calendar-grid" id="calendarGrid"></div>
      </div>

      <!-- Lista de próximos eventos cadastrados -->
      <div class="events-list">
        <h3>Próximos Eventos</h3>
        <div id="eventsList">
          <!-- Estado inicial quando não há eventos -->
          <p class="empty-state">Nenhum evento cadastrado. Que tal planejar algo especial? 💖</p>
        </div>
      </div>
    </main>
  </div>

  <!--Modal para cadastro de novo evento -->

  <div id="eventModal" class="modal">
    <div class="modal-content">
      <!-- Cabeçalho do modal com título e botão de fechar -->
      <div class="modal-header">
        <h3>Novo Evento</h3>
        <span class="close" onclick="closeEventModal()">&times;</span>
      </div>
      <!-- Formulário para adicionar evento -->
      <form id="eventForm">
        <!-- Campos básicos do evento -->
        <input type="text" id="eventTitle" placeholder="Título do evento" required>
        <input type="date" id="eventDate" required>
        <input type="time" id="eventTime">
        <textarea id="eventDescription" placeholder="Descrição (opcional)"></textarea>
        <!-- Categoria do evento -->
        <select id="eventCategory">
          <option value="date">Encontro</option>
          <option value="anniversary">Aniversário</option>
          <option value="travel">Viagem</option>
          <option value="special">Especial</option>
        </select>
        <!-- Botão para enviar o formulário -->
        <button type="submit" class="submit-btn">Adicionar</button>
      </form>
    </div>
  </div>

  <!-- Scripts do projeto -->
   <!-- Script global compartilhado -->
   <!-- Script específico de eventos -->
` }} />
    </>
  );
}
