'use client';

import { useEffect } from 'react';
import Script from 'next/script';

export default function Page() {
  useEffect(() => {
    // Lucide stub (evita erro se script ainda não carregou)
    if (typeof window !== 'undefined' && !window.lucide) {
      window.lucide = { createIcons: () => {} };
    }

    // Aguardar DOM montado para ligar eventos com segurança
    requestAnimationFrame(() => {
      // Script de gerenciamento da página de Desejos

      // Recupera a lista de desejos do localStorage ou cria um array vazio
      let wishes = JSON.parse(localStorage.getItem('wishes')) || [];

      // Define o filtro atual como "all" (todos)
      let currentFilter = 'all';

      // Exibe os desejos salvos
      displayWishes();

      // Funções para abrir e fechar o modal de cadastro
      function openWishModal() {
        document.getElementById('wishModal')?.style.setProperty('display', 'flex');
      }

      function closeWishModal() {
        document.getElementById('wishModal')?.style.setProperty('display', 'none');
        document.getElementById('wishForm')?.reset();
      }

      // Cadastro de um novo desejo
      document.getElementById('wishForm')?.addEventListener('submit', (e) => {
        e.preventDefault();
        const wish = {
          id: Date.now(),
          title: document.getElementById('wishTitle').value,
          description: document.getElementById('wishDescription').value,
          category: document.getElementById('wishCategory').value,
          priority: document.getElementById('wishPriority').value,
          estimate: document.getElementById('wishEstimate').value,
          completed: false,
          createdAt: new Date().toISOString()
        };

        wishes.push(wish);
        localStorage.setItem('wishes', JSON.stringify(wishes));
        displayWishes();
        closeWishModal();
      });

      // Filtragem de desejos por categoria
      function filterWishes(category, event) {
        currentFilter = category;
        (document.querySelectorAll('.filter-btn') || []).forEach(btn => btn.classList.remove('active'));
        event?.target?.classList.add('active');
        displayWishes();
      }

      // Função que exibe os desejos na tela
      function displayWishes() {
        const grid = document.getElementById('wishesGrid');
        if (!grid) return;

        let filteredWishes = wishes;
        if (currentFilter !== 'all') {
          filteredWishes = wishes.filter(w => w.category === currentFilter);
        }

        if (filteredWishes.length === 0) {
          grid.innerHTML = '<p class="empty-state">Nenhum desejo encontrado. Que tal sonhar um pouco? ✨</p>';
          return;
        }

        grid.innerHTML = filteredWishes.map(wish => `
          <div class="wish-card ${wish.priority}">
            <div class="wish-header">
              <div class="wish-category">${getCategoryIcon(wish.category)}</div>
              <div class="wish-priority">${getPriorityIcon(wish.priority)}</div>
            </div>
            <h4>${wish.title}</h4>
            ${wish.description ? `<p class="wish-description">${wish.description}</p>` : ''}
            ${wish.estimate ? `<p class="wish-estimate">💰 ${wish.estimate}</p>` : ''}
            <div class="wish-actions">
              <button class="complete-btn" onclick="window.completeWish(${wish.id})" title="Marcar como realizado">
                <i data-lucide="check"></i>
              </button>
              <button class="delete-btn" onclick="window.deleteWish(${wish.id})" title="Excluir">
                <i data-lucide="trash-2"></i>
              </button>
            </div>
          </div>
        `).join('');

        try { window.lucide?.createIcons?.(); } catch {}
      }

      // Ícones de categoria e prioridade
      function getCategoryIcon(category) {
        const icons = { places: '🗺️', experiences: '🎭', gifts: '🎁', goals: '🎯' };
        return icons[category] || '💫';
      }

      function getPriorityIcon(priority) {
        const icons = { low: '🔵', medium: '🟡', high: '🔴' };
        return icons[priority] || '🔵';
      }

      // Marcar desejo como realizado
      function completeWish(id) {
        if (!confirm('Parabéns! Vocês realizaram este desejo? 🎉')) return;
        const wish = wishes.find(w => w.id === id);
        if (!wish) return;

        wish.completed = true;
        wish.completedAt = new Date().toISOString();
        const completed = JSON.parse(localStorage.getItem('completed')) || [];
        completed.push(wish);
        localStorage.setItem('completed', JSON.stringify(completed));

        wishes = wishes.filter(w => w.id !== id);
        localStorage.setItem('wishes', JSON.stringify(wishes));
        displayWishes();
      }

      // Deletar desejo
      function deleteWish(id) {
        if (!confirm('Tem certeza que deseja excluir este desejo?')) return;
        wishes = wishes.filter(w => w.id !== id);
        localStorage.setItem('wishes', JSON.stringify(wishes));
        displayWishes();
      }

      // Expor funções globais
      window.completeWish = completeWish;
      window.deleteWish = deleteWish;
      window.openWishModal = openWishModal;
      window.closeWishModal = closeWishModal;
      window.filterWishes = filterWishes;

      // Recriar ícones após mutações
      try { window.lucide?.createIcons?.(); } catch {}
    }); // <-- Fecha apenas o requestAnimationFrame
  }, []); // <-- Fecha o useEffect corretamente

  return (
    <>
      <link rel="stylesheet" href="/style.css" />
      <Script
        src="https://unpkg.com/lucide@latest"
        strategy="afterInteractive"
        onLoad={() => { try { window.lucide?.createIcons?.(); } catch {} }}
      />

      {/* Corpo original mantido: estrutura e classes iguais */}
      <div className="container" dangerouslySetInnerHTML={{
        __html: `
          <nav class="sidebar">
            <h2>MyILove 💕</h2>
            <ul>
              <li><a href="/"><i data-lucide="home"></i> Início</a></li>
              <li><a href="/eventos"><i data-lucide="calendar"></i> Eventos</a></li>
              <li><a href="/desejos" class="active"><i data-lucide="heart"></i> Desejos</a></li>
              <li><a href="/anotacoes"><i data-lucide="file-text"></i> Anotações</a></li>
              <li><a href="/fotos"><i data-lucide="camera"></i> Fotos</a></li>
              <li><a href="/viagens"><i data-lucide="map"></i> Viagens</a></li>
              <li><a href="/realizadas"><i data-lucide="check-circle"></i> Realizadas</a></li>
              <li><a href="/config"><i data-lucide="settings"></i> Configurações</a></li>
            </ul>
          </nav>

          <main class="content">
            <h2>Desejos 💝</h2>
            <div class="actions">
              <button class="pink" onclick="openWishModal()">
                <i data-lucide="plus"></i> Novo Desejo
              </button>
            </div>
            <div id="wishesGrid" class="wishes-grid"></div>
          </main>

          <!-- Modal -->
          <div id="wishModal" class="modal">
            <div class="modal-content">
              <span class="close" onclick="closeWishModal()">&times;</span>
              <h3>Novo Desejo</h3>
              <form id="wishForm">
                <input id="wishTitle" type="text" placeholder="Título" required />
                <textarea id="wishDescription" placeholder="Descrição (opcional)"></textarea>
                <select id="wishCategory" required>
                  <option value="places">Lugares</option>
                  <option value="experiences">Experiências</option>
                  <option value="gifts">Presentes</option>
                  <option value="goals">Metas</option>
                </select>
                <select id="wishPriority" required>
                  <option value="low">Baixa</option>
                  <option value="medium">Média</option>
                  <option value="high">Alta</option>
                </select>
                <input id="wishEstimate" type="text" placeholder="Estimativa de custo (opcional)" />
                <button type="submit" class="pink">Salvar</button>
              </form>
            </div>
          </div>
        `
      }} />
    </>
  );
}
